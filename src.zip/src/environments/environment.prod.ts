export const environment = {
  production: true,
  domain : "http://localhost:4200",
  apiURL : "http://5.161.52.230:8877",
  appName : "MEEEMZ",
  'gClientID' : "798551186797-7ufp70425v4vq3uvruh3aofh1g58c33q.apps.googleusercontent.com"
};
